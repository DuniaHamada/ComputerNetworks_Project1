from socket import *

# reserve port 9966 on the computer
serverPort = 9966
# *The SOCK_STREAM: connection-oriented TCP protocol.
serverSocket = socket(AF_INET, SOCK_STREAM)
# Associates the socket with its local address, allowing clients to connect to the server using that address.
serverSocket.bind(("", serverPort))
# Set the socket to listening mode, where 1 represents the number of incoming connections.
serverSocket.listen(1)
print("The Server is Ready!")

# Infinite loop until it interrupted or an error occurs
while True:
    # accept() is called by the server to accept or complete the connection.
    connection_Socket, address = serverSocket.accept()
    # Receive data from the server and decode it to obtain the string.
    sentence = connection_Socket.recv(1024).decode()
    print(address)
    print(sentence)
    ip = address[0]
    port = address[1]
    words = sentence.split()

    if len(words) >= 2:
        request = words[1]
        request = request.lower()
        request = request.lstrip('/')

        if request == '' or  request == 'main_en.html' or request == 'en':  
            # Send the response status to the client after encoding it to the byte type
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            # send the type of the file after encoding it to the byte type
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            # send CRLF(new line) to the client after encoding it to the byte type
            connection_Socket.send("\r\n".encode())
            # send the requested file that we read before to the client
            with open("main_En.html", "rb") as webPage :
             connection_Socket.send(webPage.read())

        elif request == 'main_ar.html' or request == 'ar':
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: text/html; charset=utf-8\r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("main_Ar.html","rb") as webPage :
             connection_Socket.send(webPage.read())

            # If the request ends with .css then send the Cascading Style Sheet:"style.css" to the client
        elif request== 'style.css' or request=='.css':
            #send the style.css file 
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: text/css \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("style.css","rb") as webPage :
             connection_Socket.send(webPage.read())

            # If the request ends with .html then send java script code: used in the main html code
        elif request=='index.html':
            #send the index.html file 
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("index.html","rb") as webPage :
             connection_Socket.send(webPage.read())


         # If the request ends with .png then send image code to the client
        elif request=='bzu.png' or request=='.png':
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: image/jpg \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("bzu.png","rb") as webPage :
              connection_Socket.send(webPage.read())

            # If the request ends with .jpg then send image code to the client
        elif request=='b.jpg' or request=='.jpg':
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: image/png \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("b.jpg","rb") as webPage :
              connection_Socket.send(webPage.read())

        elif request == 'alaa.jpg' or request == '.jpg':
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: image/png \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("alaa.jpg", "rb") as webPage:
                connection_Socket.send(webPage.read())

        elif request == 'dunia.jpg' or request == '.jpg':
                connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
                connection_Socket.send("Content-Type: image/png \r\n".encode())
                connection_Socket.send("\r\n".encode())
                with open("dunia.jpg", "rb") as webPage:
                    connection_Socket.send(webPage.read())

        elif request == 'tarteel.jpg' or request == '.jpg':
            connection_Socket.send("HTTP/1.1 200 OK\r\n".encode())
            connection_Socket.send("Content-Type: image/png \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("tarteel.jpg", "rb") as webPage:
                connection_Socket.send(webPage.read())

        elif request=='cr':
            connection_Socket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            connection_Socket.send("Location:https://www.youtube.com/\r\n".encode())
            connection_Socket.send("\r\n".encode())

        elif request=='so':
            connection_Socket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            connection_Socket.send("Location:https://www.stackoverflow.com \r\n".encode())
            connection_Socket.send("\r\n".encode())
            
        elif request=='rt':
            connection_Socket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            connection_Socket.send("Location:https://ritaj.birzeit.edu/register/ \r\n".encode())
            connection_Socket.send("\r\n".encode())

        # If the request doesn't end with the mentioned above, then send the notfound file
        else: 
            connection_Socket.send("HTTP/1.1 404 Not Found\r\n".encode())
            connection_Socket.send("Content-Type: text/html \r\n".encode())
            connection_Socket.send("\r\n".encode())
            with open("error.html ","rb") as webPage :
              connection_Socket.send(webPage.read())
            # Close the connection
    
    connection_Socket.close()