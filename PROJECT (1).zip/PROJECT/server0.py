import socket
import time
import platform
import ctypes
import os

serverPort = 9955
serverName = socket.gethostname()
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((serverName, serverPort))
#server ready to recive the message from client 
server_socket.listen(1)
print("Server is listening on port 9955...")

while True:
    
    client_socket, addr = server_socket.accept()
    print(f"Accept connection from ", addr)

    system_platform = platform.system()
    data = client_socket.recv(1024).decode('utf-8')  # Decode the received bytes into a string

    # Check if the message contains a valid student ID
    if data.isdigit() and data in ["1222670", "1201001", "1200737"]:
        print(f"That the OS will lock the screen after 10 seconds...")
        # Send a message to the client
        client_socket.sendall("Server will lock the screen after 10 seconds".encode('utf-8'))
        # Wait for ten seconds
        time.sleep(10)

        # Lock the screen based on the operating system
        if system_platform == "Windows":
            #lock screen for windows 
            ctypes.windll.user32.LockWorkStation()
        elif system_platform == "Linux" or system_platform == "Darwin":
            os.system("gnome-screensaver-command -l")
        else:
            print(f"Screen locking not supported on {system_platform}")

    else:
        print(f"Error! Invalid student ID, no lock screen done...")