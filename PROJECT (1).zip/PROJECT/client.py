import socket

serverName = socket.gethostname()
serverPort = 9955
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect((serverName, serverPort))

try:
    studentId = input("Enter ID: ")
    clientSocket.sendall(studentId.encode('utf_8'))
    mesSentence = clientSocket.recv(1024)
    print("From Server: ", mesSentence.decode('utf_8'))


finally:
    clientSocket.close()